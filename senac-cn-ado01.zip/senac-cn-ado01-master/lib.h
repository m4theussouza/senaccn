#include<stdio.h>
#include<stdlib.h>
#include <string.h>	
int stringParaInteiro     (char *s);
int verificaBase          (int valor);
int potencia              (int base, int expoente);
int charParaInt           (char c);
int converteParaBase10    (char * numero, int base);
void InverteString        (char * numero);
void converteParaBaseN    (char * output, int numero, int baseDeDestino);