long double potencia(long double base, int expoente);
long double fatorial(long double n);
long double cosseno(long double x, long double* erro);
long double erroAbsolutoCosseno(long double x);  
long double seno(long double x, long double* erro);
long double erroAbsolutoSeno(long double x);